#!/bin/bash
sleep 3
killall 9htl 9hviewer 9hbrowser 9hmultiss 9hits
