#!/bin/bash
killall 9htl 9hviewer 9hbrowser 9hmultiss
sleep 4
/sbin/init 6
